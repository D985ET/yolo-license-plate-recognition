# LPH_Yv9 > 2024-03-20 1:15pm
https://universe.roboflow.com/car-speed-estimation/lph_yv9

Provided by a Roboflow user
License: CC BY 4.0

